# -*- coding: utf-8 -*-
"""古书阁 · 轻后端（仅 Python 标准库）
启动：python server.py  （端口 5500，同时服务静态文件与 API）
数据：data/dh.json  {users:{名:{pw,salt,ts}}, sessions:{token:名}, events:{名:[...]}, blobs:{名:{...}}}
"""
import json, os, re, hashlib, secrets, threading
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler

BASE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE, 'data')
DATA_FILE = os.path.join(DATA_DIR, 'dh.json')
LOCK = threading.Lock()

def load_db():
    try:
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {'users': {}, 'sessions': {}, 'events': {}, 'blobs': {}}

def save_db(db):
    os.makedirs(DATA_DIR, exist_ok=True)
    tmp = DATA_FILE + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(db, f, ensure_ascii=False)
    os.replace(tmp, DATA_FILE)

def hash_pw(pw, salt):
    return hashlib.sha256((salt + ':' + pw).encode('utf-8')).hexdigest()

# 学分 = 完卷*100 + 完美卷*50 + 百题答对*5 + 错题掌握*8（按快照 gushi_v1 实时计算）
def calc_score(blob):
    try:
        p = blob.get('p', {})
        done = perfect = 0
        for pid, o in p.items():
            if not isinstance(o, dict):
                continue
            if o.get('done'):
                done += 1
                ex = o.get('exam') or {}
                if ex.get('perfect'):
                    perfect += 1
        b = blob.get('btf') or {}
        btf_right = len(b.get('answered') or [])
        btf_mastered = len(b.get('mastered') or [])
        return done * 100 + perfect * 50 + btf_right * 5 + btf_mastered * 8, \
               {'done': done, 'perfect': perfect, 'btfRight': btf_right, 'btfMastered': btf_mastered}
    except Exception:
        return 0, {'done': 0, 'perfect': 0, 'btfRight': 0, 'btfMastered': 0}

def user_score(db, u):
    return calc_score(db.get('blobs', {}).get(u, {}))

class Handler(SimpleHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass  # 静默访问日志

    # ---- 工具 ----
    def send_json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def read_body(self):
        try:
            n = int(self.headers.get('Content-Length') or 0)
            if n <= 0 or n > 1 << 20:
                return None
            return json.loads(self.rfile.read(n).decode('utf-8'))
        except Exception:
            return None

    def whoami(self, token=None):
        """解析 token 为用户名，未登录返回 None。token 缺省时取 URL query"""
        if token is None:
            try:
                from urllib.parse import urlparse, parse_qs
                q = parse_qs(urlparse(self.path).query)
                token = (q.get('token') or [''])[0]
            except Exception:
                return None
        with LOCK:
            db = load_db()
            return db.get('sessions', {}).get(token)

    # ---- API ----
    def api_register(self, body):
        if not body:
            return self.send_json({'ok': 0, 'err': '请求无效'})
        u = str(body.get('u') or '').strip()
        p = str(body.get('p') or '')
        if not (2 <= len(u) <= 12) or not re.fullmatch(r'[\w\u4e00-\u9fff\-]+', u):
            return self.send_json({'ok': 0, 'err': '书名需 2~12 字（中文/字母/数字）'})
        if len(p) < 4:
            return self.send_json({'ok': 0, 'err': '口令至少 4 位'})
        with LOCK:
            db = load_db()
            if u in db.get('users', {}):
                return self.send_json({'ok': 0, 'err': '此书名已被登记'})
            salt = secrets.token_hex(8)
            db.setdefault('users', {})[u] = {'salt': salt, 'pw': hash_pw(p, salt), 'ts': __import__('time').time()}
            token = secrets.token_hex(16)
            db.setdefault('sessions', {})[token] = u
            save_db(db)
        return self.send_json({'ok': 1, 'token': token, 'u': u})

    def api_login(self, body):
        if not body:
            return self.send_json({'ok': 0, 'err': '请求无效'})
        u = str(body.get('u') or '').strip()
        p = str(body.get('p') or '')
        with LOCK:
            db = load_db()
            rec = db.get('users', {}).get(u)
            if not rec or rec['pw'] != hash_pw(p, rec['salt']):
                return self.send_json({'ok': 0, 'err': '书名或口令不确'})
            token = secrets.token_hex(16)
            db.setdefault('sessions', {})[token] = u
            save_db(db)
        return self.send_json({'ok': 1, 'token': token, 'u': u})

    def api_me(self):
        u = self.whoami()
        if not u:
            return self.send_json({'ok': 0, 'err': '未登录'})
        with LOCK:
            db = load_db()
        score, det = user_score(db, u)
        return self.send_json({'ok': 1, 'u': u, 'score': score, 'det': det})

    def api_track(self, body):
        if not body:
            return self.send_json({'ok': 0, 'err': '请求无效'})
        u = self.whoami((body.get('token') or '')[0:64])
        ev = str(body.get('ev') or '')[:24]
        k = str(body.get('k') or '')[:12]
        if not ev:
            return self.send_json({'ok': 0, 'err': '缺事件'})
        item = {
            'ev': ev, 'k': k, 'v': body.get('v') or 0,
            't': body.get('t') or __import__('time').time() * 1000
        }
        blob = body.get('blob')
        with LOCK:
            db = load_db()
            evs = db.setdefault('events', {}).setdefault(u, [])
            evs.append(item)
            del evs[:-500]  # 每人保留最近 500 条
            if isinstance(blob, dict):
                db.setdefault('blobs', {})[u] = blob
            save_db(db)
        return self.send_json({'ok': 1})

    def api_sync(self):
        u = self.whoami()
        if not u:
            return self.send_json({'ok': 0, 'err': '未登录'})
        with LOCK:
            db = load_db()
        blob = db.get('blobs', {}).get(u)
        return self.send_json({'ok': 1, 'blob': blob})

    def api_board(self):
        with LOCK:
            db = load_db()
        rows = []
        for u, rec in db.get('users', {}).items():
            score, det = user_score(db, u)
            evs = db.get('events', {}).get(u) or []
            last = evs[-1]['t'] if evs else rec.get('ts', 0) * 1000
            rows.append({'u': u, 'score': score, 'last': last, **det})
        rows.sort(key=lambda r: (-r['score'], r['u']))
        return self.send_json({'ok': 1, 'rows': rows})

    def api_history(self):
        u = self.whoami()
        if not u:
            return self.send_json({'ok': 0, 'err': '未登录'})
        with LOCK:
            db = load_db()
        evs = list(db.get('events', {}).get(u) or [])
        evs.reverse()
        return self.send_json({'ok': 1, 'u': u, 'rows': evs})

    # ---- 路由 ----
    def do_GET(self):
        path = self.path.split('?')[0]
        if path == '/api/me':
            return self.api_me()
        if path == '/api/sync':
            return self.api_sync()
        if path == '/api/board':
            return self.api_board()
        if path == '/api/history':
            return self.api_history()
        return super().do_GET()

    def do_POST(self):
        path = self.path.split('?')[0]
        body = self.read_body()
        if path == '/api/register':
            return self.api_register(body)
        if path == '/api/login':
            return self.api_login(body)
        if path == '/api/track':
            return self.api_track(body)
        if path == '/api/':
            return self.send_json({'ok': 0, 'err': '未知接口'})
        return super().do_POST()

if __name__ == '__main__':
    os.chdir(BASE)
    srv = None
    for port in (5500, 5757, 5800, 8765, 5900):
        try:
            srv = ThreadingHTTPServer(('127.0.0.1', port), Handler)
            break
        except OSError:
            continue
    if not srv:
        raise SystemExit('所有候选端口均被占用')
    print('古书阁后端已启 · http://localhost:%d' % srv.server_address[1])
    srv.serve_forever()
